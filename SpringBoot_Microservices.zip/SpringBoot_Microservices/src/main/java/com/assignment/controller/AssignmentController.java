package com.assignment.controller;

import java.util.Date;
import java.util.Map;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.service.UtilityService;

@RestController
@RequestMapping("/api")
public class AssignmentController {
	@Autowired
	UtilityService utilityService;
	
	@RequestMapping("/Fibonacci")
//	@Compressor
	String getFibonacciSeq(@RequestParam(value = "n") String no , HttpServletResponse response) {
		System.out.println("Number is :  "+ no.length());	
		setResponseHeaders(response);
		if(no.length() ==0){
			return "Error-400:Enter Some Numeric Value";
		}
		if(!utilityService.isInteger(String.valueOf(no))){
			return "Error-400:Please Enter Only Numbers";
		}
		return utilityService.getFibanocciIndex(no);
	}
	
	@RequestMapping("/ReverseWords")
	String reverseTheString(@RequestParam(value = "sentence") String sentence , HttpServletResponse response) {
		System.out.println("sentence is :  "+ sentence);
		setResponseHeaders(response);
		if(sentence.length() ==0){
			return "Error-400: Please Enter Some Value";
		}
		return utilityService.reverseString(sentence);
	}

	@RequestMapping("/TriangleType")
	String getTriangleType(@RequestParam(value = "a") String a, @RequestParam(value = "b") String b, 
			@RequestParam(value = "c") String c ,HttpServletResponse  response) {
		System.out.println("a::"+a+"::b::"+b+"::c::"+c);
		setResponseHeaders(response);
		if(a.length()==0 || b.length()==0 || c.length()==0){
			return "Error-400:Enter Some Numeric Value";
		}
		if(!utilityService.isInteger(String.valueOf(a)) || !utilityService.isInteger(String.valueOf(b))
				|| !utilityService.isInteger(String.valueOf(c))){
			return "Error-400:Please Enter Only Numbers";
		}
		int d = Integer.parseInt(a);
		int e = Integer.parseInt(b);
		int f = Integer.parseInt(c);
		return utilityService.getTriangleType(d, e, f);
	}
	
	@RequestMapping(value="/makeonearray" , method = RequestMethod.POST, produces="application/json", headers={"Content-Type= application/json"})	
	String makeonearray(@RequestBody Map<String,Object> map , HttpServletResponse response) {
		System.out.println("array is "+map.size());
		setResponseHeaders(response);
		return utilityService.makeonearray(map);
	}
	
	private void setResponseHeaders(HttpServletResponse response) {
		response.setHeader("cache-control", "no-cache");
	    response.setHeader("Pragma","no-cache");
	    response.setHeader("Expires", "-1");
	    response.setHeader("date", new Date().toString());
	    response.setHeader("Content-Encoding", "application/gzip");
	    response.setHeader("vary", "Accept-Encoding");
	}
}
