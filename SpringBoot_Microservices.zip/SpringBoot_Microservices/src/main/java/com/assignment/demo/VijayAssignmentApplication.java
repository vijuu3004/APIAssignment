package com.assignment.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages="com.assignment.controller com.assignment.service")
public class VijayAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(VijayAssignmentApplication.class, args);
	}
}
