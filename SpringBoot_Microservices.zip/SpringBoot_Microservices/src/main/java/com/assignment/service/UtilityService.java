package com.assignment.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import org.springframework.stereotype.Service;

@Service
public class UtilityService {
	
	public String getFibanocciIndex(String no){
		int a = 0;
		int b = 1;
		int num = Integer.parseInt(no);
		for (int i = 1; i <= num; i++) {
			int temp = a;
			a = a + b;
			b = temp;
		}
		return String.valueOf(a);
	}
	
	public String reverseString(String str){
		String[] words = str.split(" ");
		String reversedString = "";
		for (int i = 0; i < words.length; i++)
	        {
	           String word = words[i]; 
	           String reverseWord = "";
	           for (int j = word.length()-1; j >= 0; j--) 
		   {
			reverseWord = reverseWord + word.charAt(j);
		   }
		   reversedString = reversedString + reverseWord + " ";
		}
		return reversedString.trim();
	}

	public String getTriangleType(int a,int b,int c){
		if(a==b && a==c && b==c){
			return "Equilateral";
		}
		if(a!=b && b==c){
			return "Isoceles";
		}
		if((a==c && a!=b && c!=b) || (a==b && a!=c && b!=c)){
			return "Isoceles";
		}
			return "Scalene";
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String makeonearray(Map<String, Object> map) {
		System.out.println("Map Values:::"+map);
		List objList = null;
		TreeSet uniqVal = new TreeSet();
		Iterator iter = map.values().iterator();
		while(iter.hasNext()){
			objList = (ArrayList)iter.next();
			uniqVal.addAll(objList);
		}
		System.out.println("finalVal is now:::"+(uniqVal));	
		return uniqVal.toString();
	}
	
	public boolean isInteger(String s){
		boolean isValidInteger = false;
		try{
			Integer.parseInt(s);
			isValidInteger = true;
		}catch(NumberFormatException ne){
		}
		System.out.println("IsValidInt::::"+isValidInteger);
		return isValidInteger;
	}
}
