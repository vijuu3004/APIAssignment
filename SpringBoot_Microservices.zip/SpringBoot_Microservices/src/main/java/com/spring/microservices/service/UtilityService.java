package com.spring.microservices.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

@Service
public class UtilityService {
static final Logger logger = Logger.getLogger(UtilityService.class);
	
	public String getFibanocciIndex(String no){
		logger.info("Entering getFibanocciIndex Method");
		int a = 0;
		int b = 1;
		int num = Integer.parseInt(no);
		for (int i = 1; i <= num; i++) {
			int temp = a;
			a = a + b;
			b = temp;
		}
		logger.info("Fibonacci Value is ::"+a);
		logger.info("Exiting getFibanocciIndex Method");
		return String.valueOf(a);
	}
	
	public String reverseString(String str){
		logger.info("Entering reverseString Method");
		String[] words = str.split(" ");
		StringBuilder reversedString = new StringBuilder();
		for (int i = 0; i < words.length; i++)
	        {
	           String word = words[i]; 
	           StringBuilder reverseWord = new StringBuilder();
	           for (int j = word.length()-1; j >= 0; j--) 
		   {
			reverseWord = reverseWord.append(word.charAt(j));
		   }
		   reversedString = reversedString.append(reverseWord).append(" ");
		}
		String outputString = reversedString.toString();
		logger.info("Reversed String is :::"+outputString.trim());
		logger.info("Exiting reverseString Method");
		return outputString.trim();
	}

	public String getTriangleType(int a,int b,int c){
		logger.info("Entering getTriangleType Method");
		if(a==b && a==c){
			return "Equilateral";
		}
		if((a!=b && b==c) || (a!=c && a==b) || (a==c && b!=c)){
			return "Isoceles";
		}
		logger.info("Exiting getTriangleType Method");
			return "Scalene";
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String makeonearray(Map<String, Object> map) {
		logger.info("Entering makeonearray Method");
		List objList = null;
		TreeSet uniqVal = new TreeSet();
		Iterator iter = map.values().iterator();
		while(iter.hasNext()){
			objList = (ArrayList)iter.next();
			uniqVal.addAll(objList);
		}
		logger.info("Final Array:::"+uniqVal.toString());
		logger.info("Entering makeonearray Method");
		return uniqVal.toString();
	}
	
	public boolean isInteger(String s){
		boolean isValidInteger = false;
		try{
			Integer.parseInt(s);
			isValidInteger = true;
		}catch(NumberFormatException ne){
			logger.info("Exception in IsInteger:::"+ne.getLocalizedMessage());
		}
		logger.info("IsValidInt::::"+isValidInteger);
		return isValidInteger;
	}
}
