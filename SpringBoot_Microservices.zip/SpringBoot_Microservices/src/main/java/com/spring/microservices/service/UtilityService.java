package com.spring.microservices.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.spring.microservices.controller.Constants;

@Service
public class UtilityService {
static final Logger logger = Logger.getLogger(UtilityService.class);
	
	public String getFibanocciIndex(long no,HttpServletResponse response){
		logger.info("Entering getFibanocciIndex Method");
		BigInteger a = BigInteger.ZERO;
		BigInteger b = BigInteger.ONE;
		String result = "0";
		try{
		for (long i = 1; i < no; i++) {
			BigInteger c = a;
			a = a.add(b);
			b = c;
			}
			if(a.longValueExact() < Long.MIN_VALUE || a.longValueExact() > Long.MAX_VALUE){
				return "Error 400 : Output Value exceeds Threshold of DataType long";
			}
			result = String.valueOf(a);
		 }catch (NumberFormatException ex){
			 response.setStatus(400);
			 logger.info("Enter a valid number."+ex.getMessage());
		 }catch(ArithmeticException ae){
			 response.setStatus(400);
			 return Constants.STATUS + "Output Value exceeds Threshold of DataType long";
		 }
		logger.info("Fibonacci Value is ::"+a);
		logger.info("Exiting getFibanocciIndex Method");
		return result;
	}
	
	/*public String reverseString(String str){
		logger.info("Entering reverseString Method");
		String[] words = str.split(" ");
		StringBuilder reversedString = new StringBuilder();
		for (int i = 0; i < words.length; i++)
	        {
	           String word = words[i]; 
	           StringBuilder reverseWord = new StringBuilder();
	           for (int j = word.length()-1; j >= 0; j--) 
		   {
			reverseWord = reverseWord.append(word.charAt(j));
		   }
		   reversedString = reversedString.append(reverseWord).append(" ");
		}
		String outputString = reversedString.toString();
		logger.info("Reversed String is :::"+outputString.trim());
		logger.info("Exiting reverseString Method");
		return outputString.trim();
	}*/
	
	public String reverseString(String str){
		logger.info("Entering reverseString Method");
		String reversedString = new StringBuffer(str).reverse().toString();
		logger.info("Reversed String is :::"+reversedString);
		logger.info("Exiting reverseString Method");
		return reversedString;
	}

	public String getTriangleType(int a,int b,int c){
		logger.info("Entering getTriangleType Method");
		if(a==b && a==c){
			return "Equilateral";
		}
		if((a!=b && b==c) || (a!=c && a==b) || (a==c && b!=c)){
			return "Isoceles";
		}
		logger.info("Exiting getTriangleType Method");
			return "Scalene";
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String makeonearray(Map<String, Object> map , HttpServletResponse response) {
		logger.info("Entering makeonearray Method");
		List objList = null;
		TreeSet uniqVal = new TreeSet();
		try{
		Iterator iter = map.values().iterator();
		while(iter.hasNext()){
			objList = (ArrayList)iter.next();
			if(objList!=null && objList.contains(null)){
				response.setStatus(400);
				return Constants.STATUS + "Please enter non null Values" ;
			}
			uniqVal.addAll(objList);
		}
		}catch (ClassCastException e) {
			response.setStatus(400);
	        return Constants.STATUS + "Please enter similar data types in Array" ;
	    }
		logger.info("Final Array:::"+uniqVal.toString());
		logger.info("Entering makeonearray Method");
		return uniqVal.toString();
	}
	
	public boolean isInteger(String s){
		boolean isValidInteger = false;
		try{
			Integer.parseInt(s);
			isValidInteger = true;
		}catch(NumberFormatException ne){
			logger.info("Exception in IsInteger:::"+ne.getLocalizedMessage());
		}
		logger.info("IsValidInt::::"+isValidInteger);
		return isValidInteger;
	}
}
