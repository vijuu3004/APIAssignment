package com.spring.microservices.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.GZIPOutputStream;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.ext.Provider;
import javax.ws.rs.ext.WriterInterceptor;
import javax.ws.rs.ext.WriterInterceptorContext;

@Provider
@Compressor
public class GZIPWriterInterceptor implements WriterInterceptor{
	
	public GZIPWriterInterceptor(){
		super();
	}
	
	public GZIPWriterInterceptor(@Context HttpHeaders context){
		this.context = context;
	}
	
	private HttpHeaders context;
	@Override	
	public void aroundWriteTo(WriterInterceptorContext writerInterceptorContext)
			throws IOException, WebApplicationException {
		String acceptEncoding = context.getHeaderString("Accept-Encoding");
		if(acceptEncoding!=null && acceptEncoding.contains("gzip")){
			final OutputStream outputstream = writerInterceptorContext.getOutputStream();
			writerInterceptorContext.setOutputStream(new GZIPOutputStream(outputstream));
			writerInterceptorContext.getHeaders().putSingle("Content-Encoding", "gzip");
		}
		writerInterceptorContext.proceed();
	}
}
