package com.spring.microservices.controller;

import java.math.BigInteger;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.apache.log4j.Logger;

import com.spring.microservices.service.UtilityService;

@RestController
@RequestMapping("/api")
public class RestAPIController {
	static final Logger logger = Logger.getLogger(RestAPIController.class);
	@Autowired
	UtilityService utilityService;
	
	@RequestMapping("/Fibonacci")
	@Compressor
	String getFibonacciSeq(@Valid @RequestParam(value = "n") String no , HttpServletResponse response , HttpServletRequest request) {
		logger.info("Entering getFibonacciSeq Method");
		logger.info("Number input is :  "+ no);
		long inputVal = 0;
		try{
			inputVal = new BigInteger(no.trim()).longValueExact();
			if(inputVal==0 || inputVal<0 || no.length()==0){
				response.setStatus(400);
				return Constants.STATUS + Constants.POSITIVE_NUM;
			}
		}catch(NumberFormatException ae){
			response.setStatus(400);
			return Constants.STATUS + Constants.POSITIVE_NUM;
		}
		catch (ArithmeticException e) {
			response.setStatus(400);
	        return Constants.STATUS + Constants.VALUE_EXCEEDS + no;
	    }catch (IllegalArgumentException ie) {
			response.setStatus(400);
	        return "Please remove Forward Slashes if any in the request URL";
	    }
		setResponseHeaders(response);
		String output = utilityService.getFibanocciIndex(inputVal,response);
		logger.info("Exiting getFibonacciSeq Method");
		return output;
	}
	
	@RequestMapping("/ReverseWords")
	@Compressor
	String reverseTheString(@RequestParam(value = "sentence") String sentence , HttpServletResponse response) {
		logger.info("Entering reverseTheString Method");
		logger.info("sentence is : :"+sentence);
		try{
		if(sentence.length() ==0){
			response.setStatus(400);
			return Constants.STATUS + Constants.ALPHA_NULL;
		}setResponseHeaders(response);
		}catch(IllegalArgumentException iae){
			response.setStatus(400);
			return Constants.STATUS + "Please do not enter these characters '#\'";
		}
		
		logger.info("Exiting reverseTheString Method");
		return utilityService.reverseString(sentence);
	}

	@RequestMapping("/TriangleType")
	@Compressor
	String getTriangleType(@RequestParam(value = "a") String a, @RequestParam(value = "b") String b, 
			@RequestParam(value = "c") String c ,HttpServletResponse  response) {
		logger.info("Entering getTriangleType Method");
		logger.info("a::"+a+"::b::"+b+"::c::"+c);
		if(a.length()==0 && b.length()==0 && c.length()==0){
			response.setStatus(400);
			return Constants.STATUS + "Please Input value for a , b , c";
		}
		if(a.length()==0 && b.length()==0 && c.length()!=0){
			response.setStatus(400);
			return Constants.STATUS + "Please Input value for a , b ";
		}
		if(a.length()==0 && b.length()!=0 && c.length()==0){
			response.setStatus(400);
			return Constants.STATUS + "Please Input value for a , c ";
		}
		if(a.length()!=0 && b.length()==0 && c.length()==0){
			response.setStatus(400);
			return Constants.STATUS + "Please Input value for b , c ";
		}
		if(a.length()==0){
			response.setStatus(400);
			return Constants.STATUS + "Please Input value for a";
		}
		if(b.length()==0){
			response.setStatus(400);
			return Constants.STATUS + "Please Input value for b";
		}
		if(c.length()==0){
			response.setStatus(400);
			return Constants.STATUS + "Please Input value for c";
		}
		int d = 0;
		int e = 0;
		int f = 0;
		try{
			d = new BigInteger(a.trim()).intValueExact();
			e = new BigInteger(b.trim()).intValueExact();
			f = new BigInteger(c.trim()).intValueExact();
			if(d==0 || d<0 ){
				response.setStatus(400);
				return Constants.STATUS + Constants.POSITIVE_NUM + " for a";
			}
			if(e==0 || e<0 ){
				response.setStatus(400);
				return Constants.STATUS + Constants.POSITIVE_NUM + " for b";
			}
			if(f==0 || f<0 ){
				response.setStatus(400);
				return Constants.STATUS + Constants.POSITIVE_NUM + " for c";
			}
			if(d > e + f || e > d + f || f > d + e){
				 response.setStatus(400);
				 return Constants.STATUS+Constants.TRIANGLE_VIOLATION;
				 }
		}catch(NumberFormatException ne){
			response.setStatus(400);
			return Constants.STATUS + Constants.POSITIVE_NUM;
		}
		catch (ArithmeticException ae) {
			response.setStatus(400);
	        return Constants.STATUS + Constants.VALUE_EXCEEDS;
	    }
		setResponseHeaders(response);
		logger.info("Exiting getTriangleType Method");
		return utilityService.getTriangleType(d, e, f);
	}
	
	@RequestMapping(value="/makeonearray" , method = RequestMethod.POST, produces="application/json", headers={"Content-Type= application/json"})
	@Compressor
	String makeonearray(@Valid @RequestBody Map<String,Object> map , HttpServletResponse response) {
		logger.info("Entering makeonearray Method");
		logger.info("array is "+map.size());
		setResponseHeaders(response);
		logger.info("Exiting makeonearray Method");
		return utilityService.makeonearray(map,response);
	}
	
	private void setResponseHeaders(HttpServletResponse response) {
		response.setHeader("cache-control", "no-cache");
	    response.setHeader("Pragma","no-cache");
	    response.setHeader("Expires", "-1");
	    response.setHeader("date", new Date().toString());
	    response.setHeader("Content-Encoding", "application/gzip");
	    response.setHeader("vary", "Accept-Encoding");
	}
}
