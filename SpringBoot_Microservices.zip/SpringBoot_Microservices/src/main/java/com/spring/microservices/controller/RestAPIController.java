package com.spring.microservices.controller;

import java.util.Date;
import java.util.Map;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.apache.log4j.Logger;

import com.spring.microservices.service.UtilityService;

@RestController
@RequestMapping("/api")
public class RestAPIController {
	static final Logger logger = Logger.getLogger(RestAPIController.class);
	@Autowired
	UtilityService utilityService;
	
	@RequestMapping("/Fibonacci")
	@Compressor
	String getFibonacciSeq(@RequestParam(value = "n") String no , HttpServletResponse response) {
		logger.info("Entering getFibonacciSeq Method");
		logger.info("Number is :  "+ no.length());
		setResponseHeaders(response);
		if(no.length() ==0){
			return Constants.STATUS + Constants.NULL_NUM;
		}
		if(!utilityService.isInteger(String.valueOf(no))){
			return Constants.STATUS + Constants.ALPHA_NUM;
		}
		logger.info("Exiting getFibonacciSeq Method");
		return utilityService.getFibanocciIndex(no);
	}
	
	@RequestMapping("/ReverseWords")
	@Compressor
	String reverseTheString(@RequestParam(value = "sentence") String sentence , HttpServletResponse response) {
		logger.info("Entering reverseTheString Method");
		logger.info("sentence is : :"+sentence);
		setResponseHeaders(response);
		if(sentence.length() ==0){
			return Constants.STATUS + Constants.ALPHA_NULL;
		}
		logger.info("Exiting reverseTheString Method");
		return utilityService.reverseString(sentence);
	}

	@RequestMapping("/TriangleType")
	@Compressor
	String getTriangleType(@RequestParam(value = "a") String a, @RequestParam(value = "b") String b, 
			@RequestParam(value = "c") String c ,HttpServletResponse  response) {
		logger.info("Entering getTriangleType Method");
		logger.info("a::"+a+"::b::"+b+"::c::"+c);
		setResponseHeaders(response);
		if(a.length()==0 || b.length()==0 || c.length()==0){
			return Constants.STATUS + Constants.NULL_NUM;
		}
		if(!utilityService.isInteger(String.valueOf(a)) || !utilityService.isInteger(String.valueOf(b))
				|| !utilityService.isInteger(String.valueOf(c))){
			return Constants.STATUS+Constants.ALPHA_NUM;
		}
		int d = Integer.parseInt(a);
		int e = Integer.parseInt(b);
		int f = Integer.parseInt(c);
		logger.info("Exiting getTriangleType Method");
		return utilityService.getTriangleType(d, e, f);
	}
	
	@RequestMapping(value="/makeonearray" , method = RequestMethod.POST, produces="application/json", headers={"Content-Type= application/json"})
	@Compressor
	String makeonearray(@RequestBody Map<String,Object> map , HttpServletResponse response) {
		logger.info("Entering makeonearray Method");
		logger.info("array is "+map.size());
		setResponseHeaders(response);
		logger.info("Exiting makeonearray Method");
		return utilityService.makeonearray(map);
	}
	
	private void setResponseHeaders(HttpServletResponse response) {
		response.setHeader("cache-control", "no-cache");
	    response.setHeader("Pragma","no-cache");
	    response.setHeader("Expires", "-1");
	    response.setHeader("date", new Date().toString());
	    response.setHeader("Content-Encoding", "application/gzip");
	    response.setHeader("vary", "Accept-Encoding");
	}
}
