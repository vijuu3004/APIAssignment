package com.spring.microservices.controller;

public class Constants {
	
	private Constants() {
        // restrict instantiation
}

public static final String STATUS= "ERROR_400 : ";
public static final String NULL_NUM= "Please Enter Some Numeric Value";
public static final String POSITIVE_NUM= "Please Enter Positive Integer Values greater than 0";
public static final String VALUE_EXCEEDS= "Input value exceeds Max Threshold Value for this function";
public static final String ALPHA_NUM= "Please Enter Only Numbers";
public static final String ALPHA_NULL= "Please Enter Some Value";
public static final String TRIANGLE_VIOLATION="Triangle Inequality : Sum of any two sides must be larger than the remaining side";
}
