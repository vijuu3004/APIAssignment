package com.springboot.api.test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import io.restassured.http.ContentType;
import java.util.HashMap;
import java.util.Map;
import org.junit.Test;

public class TestRestApi {

	@Test
	public void testFibonacciSeries_Num() {
		String val="55";
		given().when().
		get("http://localhost:2017/api/Fibonacci?n=10").then().assertThat().statusCode(200).
		body(equalTo(val));
	};
	
	@Test
	public void testFibonacciSeries_AlphaNum() {
		String val="Error-400:Please Enter Only Numbers";
		given().when().
		get("http://localhost:2017/api/Fibonacci?n=10a").then().assertThat().statusCode(200).
		body(equalTo(val));
	};
	
	@Test
	public void testFibonacciSeries_nullValues() {
		String val="Error-400:Enter Some Numeric Value";
		given().when().
		get("http://localhost:2017/api/Fibonacci?n=").then().assertThat().statusCode(200).
		body(equalTo(val));
	};
	
	@Test
	public void testTriangleServices() {
		String val="Equilateral";
		given().when().
		get("http://localhost:2017/api/TriangleType?a=6&b=6&c=6").then().assertThat().statusCode(200).
		body(equalTo(val));
	};

	@Test
	public void testTriangleServices_AlphaNum() {
		String val="Error-400:Please Enter Only Numbers";
		given().when().
		get("http://localhost:2017/api/TriangleType?a=6a&b=6&c=6").then().assertThat().statusCode(200).
		body(equalTo(val));
	};
	
	@Test
	public void testTriangleServices_nullValues() {
		String val="Error-400:Enter Some Numeric Value";
		given().when().
		get("http://localhost:2017/api/TriangleType?a=6a&b=6&c=").then().assertThat().statusCode(200).
		body(equalTo(val));
	};
	
	@Test
	public void testReverseWordServices() {
		String val="woh era uoy";
		given().when().
		get("http://localhost:2017/api/ReverseWords?sentence=how are you").then().assertThat().statusCode(200).
		body(equalTo(val));
	};

	@Test
	public void testReverseWord_nullValues() {
		String val="Error-400: Please Enter Some Value";
		given().when().
		get("http://localhost:2017/api/ReverseWords?sentence=").then().assertThat().statusCode(200).
		body(equalTo(val));
	};
	
	@Test
	public void testMakeOneArrayServices() {
		String val="[1, 2, 3, 4, 5]";
		Map<String,Object> jsonAsMap = new HashMap<String, Object>();
		int[] a = {1,2,3};
		int[] b = {1,2,3,4};
		int[] c = {1,2,3,4,5};
		jsonAsMap.put("array1",a);
		jsonAsMap.put("array2",b);
		jsonAsMap.put("array3",c);
		given().accept(ContentType.JSON).contentType(ContentType.JSON).body(jsonAsMap).when().post("http://localhost:2017/api/makeonearray").
		then().assertThat().body(equalTo(val));
	};
}
