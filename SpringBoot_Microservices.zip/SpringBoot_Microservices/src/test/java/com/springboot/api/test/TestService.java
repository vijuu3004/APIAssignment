package com.springboot.api.test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.junit.Test;

import com.spring.microservices.controller.RestAPIController;
import com.spring.microservices.service.UtilityService;

public class TestService {
	static final Logger logger = Logger.getLogger(TestService.class);
	UtilityService utilSer = new UtilityService();
	RestAPIController apiCtl = new RestAPIController();
	
	@Test
	public void testgetFibonacciSeq() {
		long val=10;
		String result = utilSer.getFibanocciIndex(val,null);
		assertTrue(result.equals("34"));
	};
	
	@Test
	public void testgetFibonacciSeq_Neg() {
		long val=10;
		String result = utilSer.getFibanocciIndex(val,null);
		assertFalse(result.equals("30"));
		System.out.println("API::::"+apiCtl.getClass().getAnnotations());
	};
	
	@Test
	public void testgetTriangleType(){
		int a=10;
		int b=5;
		int c=9;
		String result = utilSer.getTriangleType(a, b, c);
		assertTrue(result.equals("Scalene"));
	};
	
	@Test
	public void testgetTriangleType_Neg(){
		int a=10;
		int b=5;
		int c=9;
		String result = utilSer.getTriangleType(a, b, c);
		assertFalse(result.equals("Equilateral"));
	};
	
	@Test
	public void testReverseWords(){
		String word = "This is a sample";
		String result = utilSer.reverseString(word);
		assertTrue(result.equals("elpmas a si sihT"));
	};

}
